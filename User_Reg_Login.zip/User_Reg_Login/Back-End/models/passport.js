const mongoose=require('mongoose');
const joi=require('joi');


const pasportSchema=new mongoose.Schema({
    passportNo:{
        type:String,
        required:true,
        unique:true
    }
})
const Passport=mongoose.model('passport',pasportSchema);

function validatePassport(passport){
    let schema={
        passportNo:joi.string().required().length(8)
    }
    return joi.validate(passport,schema)
}

module.exports.Passport=Passport;
module.exports.validatePassport=validatePassport;