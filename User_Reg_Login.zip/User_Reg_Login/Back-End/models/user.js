const mongoose=require('mongoose');
const joi=require('joi');


const userSchema=new mongoose.Schema({
    email:{
        type:String,
        required:true,
        unique:true
    },
    mobileNo:{
        type:Number,
        required:true,
        unique:true,
        length:10
    },
    passportNo:{
        type:String,
        required:true,
        unique:true,
        length:8
    },
    userName:{
        type:String,
        minlength:3,
        required:true
    },
    password:{
        type:String,
        required:true,
    },
    registrationNo:{
        type:Number,
        required:true,
        length:6
    }
})
const User=mongoose.model('user',userSchema);

function validateUser(user){
    let schema={
        email:joi.string().required(),
        mobileNo:joi.string().required().regex(/\d{10}/),
        passportNo:joi.string().required().length(8),
        userName:joi.string().required().min(3),
        password:joi.string().required().min(8)
    }
    return joi.validate(user,schema)
}

module.exports.User=User;
module.exports.validateUser=validateUser;