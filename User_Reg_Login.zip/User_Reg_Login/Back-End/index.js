const express=require('express');
const connection=require('./dbconnect')();
const cors=require('cors');

const passport=require('./routes/passport');
const user=require('./routes/user');
const authorization=require('./routes/authorization')

const app=express();

const PORT=process.env.port|3000;

app.use(cors({credentials: true, origin: "http://localhost:4200"}));

app.use(express.json());
app.use('/api/passport',passport);
app.use('/api/user',user);
app.use('/api/authorization',authorization)

app.use((err,req,res,next)=>{
    res.status(400).send({message:"something went wrong :"+err});
})

app.listen(PORT,()=>{
    console.log("listening to port "+PORT)
});