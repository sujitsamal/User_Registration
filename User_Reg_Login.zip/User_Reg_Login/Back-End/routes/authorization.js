const express=require('express');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');

const {User}=require('../models/user');
const exceptionHandeler=require('../exceptionHandeler');

const router=express.Router();

const JWT_SECRET="secretkey";

router.post('/',exceptionHandeler(async (req,res)=>{
    let credential=req.body;
    let user= await User.findOne({$or:[{email:credential.id},{mobileNo:+credential.id||0}]})
    if(user){
        if(bcrypt.compareSync(credential.password,user.password)){
            let token=jwt.sign({userName:user.userName},JWT_SECRET)
            res.send({'token':token})
        }
        else{
            res.status(401).send({message:"invalid Credentials"})
        }
    }
    else{
        res.status(401).send({message:"invalid Credentials"})
    }
    res.send();
}))

module.exports=router;