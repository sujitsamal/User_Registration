const express=require('express');
const router=express.Router();
const exceptionHandeler=require('../exceptionHandeler');
const {Passport,validatePassport}=require('../models/passport');

router.get('/:passportNo',exceptionHandeler(async (req,res)=>{
    let passportNo=req.params.passportNo;
    let passport=await Passport.findOne({passportNo:passportNo})
    if(passport){
        res.send(true)
    }
    else{
        res.status(404).send("invalid");
    }
}))

router.post('/',exceptionHandeler(async (req,res)=>{
    let passport=req.body;
    let result=validatePassport(passport);
    if(!result.error){
        let newPassport=new Passport({
            passportNo:passport.passportNo
        });
        let addedPassport = await newPassport.save();
        res.send(addedPassport);
    }
    else{
        res.status(400).send(result.error);
    }
}))

module.exports=router;
