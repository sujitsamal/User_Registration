const express=require('express');
const bcrypt=require('bcryptjs');
const router=express.Router();

const exceptionHandeler=require('../exceptionHandeler');
const {User,validateUser}=require('../models/user');
const {Passport,validatePassport}=require('../models/passport');

router.post('/',exceptionHandeler(async (req,res)=>{
    let user=req.body;
    let result=validateUser(user);
    if(!result.error){
        let passport=await Passport.findOne({passportNo:user.passportNo})
        if(passport){
            let maxRegno= await User.findOne().select({registrationNo:1,_id:0}).sort({registrationNo:-1});
            registrationNo=maxRegno?maxRegno.registrationNo+1:100000;
            let encPassword=bcrypt.hashSync(user.password,10)
            let newUser=new User({
                email:user.email,
                mobileNo:user.mobileNo,
                passportNo:user.passportNo,
                userName:user.userName,
                password:encPassword,
                registrationNo:registrationNo
            });
            let addedUser = await newUser.save();
            reg={registrationNo:addedUser.registrationNo}
            res.send(reg);
        }
        else{
            res.status(400).send({message:"invalid passportNo"});  
        }
    }
    else{
        res.status(400).send(result.error);
    }
}))

module.exports=router;
