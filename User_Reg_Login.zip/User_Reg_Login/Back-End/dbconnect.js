const mongoose=require('mongoose');
const mongoPass=process.env.mongoPass|12345;;
const url="mongodb://sujit:"+mongoPass+"@cluster0-shard-00-00-u0fin.mongodb.net:27017,cluster0-shard-00-01-u0fin.mongodb.net:27017,cluster0-shard-00-02-u0fin.mongodb.net:27017/USER-REGSTRATION?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true";
function connectDB(){
return mongoose.connect(url,()=>{
    console.log("Connected to db")
});
}
module.exports=connectDB;