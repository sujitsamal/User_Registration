import { Directive,Input } from '@angular/core';
import { AbstractControl, ValidatorFn,NG_VALIDATORS,Validator } from '@angular/forms';

@Directive({
  selector: '[passmatch][ngModel]',
  providers: [
    { provide: NG_VALIDATORS, useExisting: PassmatchDirective, multi: true }
  ]
})
export class PassmatchDirective implements Validator{
  @Input('password') password;
  constructor() { }
  validate(c: AbstractControl): { [key: string]: any } {
    if (c.value==this.password.value) return null;
    else return { validateEqual: false };
  }

}
