import { HttpClient,HttpHeaders } from '@angular/common/http';

export function setHeader(){
   let headers = new HttpHeaders({ "content-type": "application/json"});
   let options = { headers: headers ,withCredentials: true};
   return options
}