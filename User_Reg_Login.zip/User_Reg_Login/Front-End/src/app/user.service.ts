import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { setHeader } from './http-header';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url="http://localhost:3000/api/user";
  headerOption=setHeader();
  constructor(private http:HttpClient) { }
  registerUser(user){
    delete(user.cPassword);
    delete(user.tc);
    return this.http.post(this.url,user,this.headerOption)
  }
}