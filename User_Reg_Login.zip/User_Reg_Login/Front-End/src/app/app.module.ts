import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ErrorHandler } from '@angular/core';

import { AppComponent } from './app.component';
import { RegestrationComponent } from './regestration/regestration.component';

import { PassportService } from './passport.service';
import { HttpClientModule } from '@angular/common/http';
import { PassmatchDirective } from './passmatch.directive';
import { ValidatePassportDirective } from './validate-passport.directive';
import { MobileNoRestrictDirective } from './mobile-no-restrict.directive';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { LoginComponent } from './login/login.component';
import { LoginSuccessComponent } from './login-success/login-success.component';
import { Authguard } from './authguard.service';
import { GlobalErrorHandeler } from './GlobalErrorHendeler';


@NgModule({
  declarations: [
    AppComponent,
    RegestrationComponent,
    PassmatchDirective,
    ValidatePassportDirective,
    MobileNoRestrictDirective,
    RegSuccessComponent,
    LoginComponent,
    LoginSuccessComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'',redirectTo:"/register",pathMatch:'full'},
      {path:'register',component:RegestrationComponent},
      {path:'reg-succ/:regNo',component:RegSuccessComponent},
      {path:'login',component:LoginComponent},
      {path:'login-succ',component:LoginSuccessComponent,canActivate:[Authguard]},
      {path:'**',redirectTo:"/register"}
    ])
  ],
  providers: [
    {provide:ErrorHandler,useClass:GlobalErrorHandeler}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
