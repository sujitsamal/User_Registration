import { ErrorHandler } from "@angular/core";

export class GlobalErrorHandeler implements ErrorHandler{
    handleError(error){
        alert("An unexpected Error Occoured");
        console.log(error)
    }
}