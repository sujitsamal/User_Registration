import { Directive,HostListener,Input} from '@angular/core';

@Directive({
  selector: '[mobileNoRestrict]'
})
export class MobileNoRestrictDirective {
  constructor() { }
  @Input('mobile')mobileNo;
  
  @HostListener('keyup') validateMobileNo(){
    console.log(this.mobileNo);
    this.mobileNo.value=this.mobileNo.value.substring(0,10)
    if(isNaN(this.mobileNo.value)){
      this.mobileNo.value=this.mobileNo.value.substring(0,this.mobileNo.value.length-1)
    }
  }
  
}
