import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  token;
  invalid=false;
  constructor(private aservice:AuthService,private router:Router) { }
  submit(f){
    this.aservice.login(f.value).subscribe(
      (res)=>{
        this.token=res['token'];
        localStorage.setItem('token',this.token);
        this.router.navigate(['/login-succ'])
      },
      (err)=>{
        if(err.status==401){
          this.invalid=true;
          setTimeout(()=>{this.invalid=false},5000)
        }
        else{
          throw err;
        }
      })
  }
}
