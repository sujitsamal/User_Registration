import { Component } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-success',
  templateUrl: './login-success.component.html',
  styleUrls: ['./login-success.component.css']
})
export class LoginSuccessComponent {
  userName;
  helper=new JwtHelperService();
  constructor(private router:Router) { 
    this.userName=this.helper.decodeToken(localStorage.getItem('token')).userName
  }
  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/login'])
  }

}
