import { Component } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-regestration',
  templateUrl: './regestration.component.html',
  styleUrls: ['./regestration.component.css']
})
export class RegestrationComponent {
  mobile;
  submitted=false;
  duplicateDetails=false;
  constructor(private uservice:UserService,private router:Router) { }

  highlight(element){
    element.highlight=true;
    setTimeout(()=>{element.highlight=false},5000)
  }
  validateMobileNo(){
    this.mobile=this.mobile.substring(0,10)
    if(isNaN(this.mobile)){
      this.mobile=this.mobile.substring(0,this.mobile.length-1)
    }
  }

  submit(f){
    this.uservice.registerUser(f.value).subscribe(
      (res)=>{
        this.router.navigate(['/reg-succ',res['registrationNo']]);
      },
      (err)=>{
        if(err.message.indexOf('duplicate')){
          this.duplicateDetails=true; 
        }
        else{
          throw err;
        }
      }
    )    
  }
}