import { Directive,Input } from '@angular/core';
import { AbstractControl, ValidatorFn,NG_ASYNC_VALIDATORS,Validator } from '@angular/forms';
import { PassportService } from 'src/app/passport.service';

@Directive({
  selector: '[validatePassport][ngModel]',
  providers: [
    { provide: NG_ASYNC_VALIDATORS, useExisting: ValidatePassportDirective, multi: true }
  ]
})
export class ValidatePassportDirective implements Validator{
  constructor(private pservice:PassportService) { }
  validate(c: AbstractControl): Promise<{ [key: string]: any }|null> {
    if(c.value && c.value.length==8){
      return new Promise((resolve,reject)=>{
        this.pservice.validatePassport(c.value).subscribe(
          (res)=>{
            resolve(null);
          },
          (err)=>{
            resolve({ invalid: true });
          }
        )
      })
    }
    else return null;
  }
}
