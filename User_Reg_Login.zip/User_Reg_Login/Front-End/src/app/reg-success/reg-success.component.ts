import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-reg-success',
  templateUrl: './reg-success.component.html',
  styleUrls: ['./reg-success.component.css']
})
export class RegSuccessComponent  {
  registrationNo;
  constructor(private activatedRoute:ActivatedRoute) {
    this.registrationNo=this.activatedRoute.snapshot.paramMap.get('regNo')
   }

}
