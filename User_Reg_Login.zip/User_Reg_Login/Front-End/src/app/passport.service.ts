import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { setHeader } from './http-header';

@Injectable({
  providedIn: 'root'
})
export class PassportService {
  url="http://localhost:3000/api/passport";
  headerOption=setHeader();
  constructor(private http:HttpClient) { }
  validatePassport(passportNo){
  return this.http.get(this.url+'/'+passportNo,this.headerOption)
  }
}
